module ProductHelper
end
